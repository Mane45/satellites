import './SatelliteLayer.css';
import SatelliteTest from '../SceneWrapper/components/SatelliteTest';

function SatelliteLayer() {
    return (
        <div id="base-container">
            {/* <SatelliteTest graphicProperties={{line1: "1 25994U 99068A   22192.16952012  .00000246  00000+0  64342-4 0  9997", line2: "2 25994  98.1361 263.5453 0001353 100.4260 344.0443 14.57155209200072"}} /> */}
        </div>
    )
}
export default SatelliteLayer