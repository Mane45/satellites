import { useState, useEffect } from "react";
import { loadModules } from "esri-loader";
import { getSatelliteLocation } from "../../../helpers/satelliteCoords";
import { twoline2satrec } from "satellite.js";

const ZoomToSatellite = (props) => {
    return (
        console.log("Zoom to satellite")
    )
}
export default ZoomToSatellite;