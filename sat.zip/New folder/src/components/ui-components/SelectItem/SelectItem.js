function Item(props) {
    return(
        <h2>{props.lines.name}</h2>
        //console.log(10)
    )
}

export default Item