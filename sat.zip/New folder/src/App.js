import React from "react";

import { SceneWrapper } from "./components/SceneWrapper/SceneWrapper";

export const App = () => {
  return (
    <>
      <SceneWrapper />
    </>
  );
};
